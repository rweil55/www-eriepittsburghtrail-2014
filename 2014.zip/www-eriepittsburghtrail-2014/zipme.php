    <?php
    ini_set("display_errors", true);
    require_once "rrw_zipmeWorker.php";
    ?>
